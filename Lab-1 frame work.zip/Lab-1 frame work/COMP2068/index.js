import express, { request } from "express";
import dotenv from "dotenv";

dotenv.config();

// Creats an app object
const app = express();

app.use(express.urlencoded ({extended: true}));
app.use(express.json());


app.get("/", (request, response) => {
    response.status(200).send("Hello World");
 
 });

 app.get("/id", (req,res,next)=> {
     const id = req?.params?. id;

     //GTFO
     
     if (isNaN(id)) {
        return next (new Error(`Parameter is required to be a number. ${id} is not a number`));
     }
     res.send (`Your requested id number ${id}`);

 });

 app.use((error, req, res, next) => {
    console.error(error);
    res.status(403).send(error.message);

 });

 app.listen(3000, () => {
    console.log(`API listening on port http://localhost:$(process.emv.PORT)`);

 } ); 